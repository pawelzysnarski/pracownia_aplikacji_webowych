__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Paweł Zysnarski 4C"
import datetime
from typing import List

from models.Grades import Grades
from models.Student import Student
from models.Subject import Subject
from models.Teacher import Teacher
from year_grade import year_grade
import json
teachers:List[Teacher]=[]
subjects:List[Subject]=[]
students:List[Student]=[]
grades:List[Grades]=[]
with open("teachers.txt","r") as f:
    for line in f.readlines():
        _id, name, surname = line.strip().split(" ")
        _id = int(_id)
        teachers.append(Teacher(_id,name,surname))
with open("subjects.txt","r") as f:
    for line in f.readlines():
        _id, name, t_id = line.strip().split(" ")
        _id = int(_id)
        t_id = int(t_id)
        teacher = next((t for t in teachers if t._id == t_id), None)
        if teacher:
            subjects.append(Subject(_id,name,teacher))
with open("students.txt","r") as f:
    for line in f.readlines():
        _id, name, surname, birthdate = line.strip().split(" ")
        _id = int(_id)
        birthdate = datetime.datetime.strptime(birthdate,'%Y-%m-%d').date()
        students.append(Student(_id,name,surname,birthdate))
with open("grades.txt","r") as f:
    for line in f.readlines():
        u_id,s_id,gradeline = line.strip().split(" ")
        u_id = int(u_id)
        s_id = int(s_id)
        gradeline = gradeline.strip().split(",")
        grd:List[int]=[]
        for grade in gradeline:
            grd.append(int(grade))
        student = next((t for t in students if t._id == u_id), None)
        subject = next((t for t in subjects if t._id == s_id), None)
        if student and subject:
            grade = Grades(student,subject)
            grade.grades=grd
            grades.append(grade)
wyniki = []
for s in students:
    print(s)
    student_key = str(s)
    student_dict = {student_key: {}}
    for sub in subjects:
        print("\t", sub.name)
        for grd in (x for x in grades if x.student == s and x.subject == sub):
            grades_str = ", ".join(map(str, grd.get_grades))
            avg = round(grd.get_average, 2)
            y_grade = year_grade(avg)
            print("\t\tOceny:", grades_str)
            print("\t\tŚrednia:", avg)
            print("\t\tOcena:", y_grade)
            student_dict[student_key][sub.name] = {
                "Oceny": grades_str,
                "Srednia": avg,
                "Ocena roczna": y_grade
            }
    wyniki.append(student_dict)
    print("\n")
with open('students.json', 'w', encoding='utf-8') as f:
    json.dump(wyniki, f, indent=4, ensure_ascii=False)
print("="*50)
print()
wyniki = []
for sub in subjects:
    subject_key = str(sub.name)
    subject_dict = {subject_key: {}}
    print(sub.name + ":")
    for teach in (x for x in teachers if x == sub.teacher):
        print("\tNauczyciel:", teach)
        grades_list = []
        for grd in (x for x in grades if x.subject == sub):
            grades_list.extend(grd.get_grades)
        formatted_grades = ", ".join(map(str, grades_list))
        print("\tOceny:", formatted_grades)
        subject_dict[subject_key] = {
            "Nauczyciel": str(teach),
            "Oceny": grades_list
        }
    wyniki.append(subject_dict)
with open('subjects.json', 'w', encoding='utf-8') as f:
    json.dump(wyniki, f, indent=4, ensure_ascii=False)